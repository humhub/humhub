<?php
return array (
  '<strong>Most</strong> active people' => 'Pessoa <strong>mais</strong> ativa',
  'Comments created' => 'Comentários criados',
  'Likes given' => 'Curtidas dadas',
  'Posts created' => 'Posts criados',
);
