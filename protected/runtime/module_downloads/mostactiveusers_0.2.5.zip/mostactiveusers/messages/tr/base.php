<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Aktif</strong> kişiler',
  'Back to modules' => 'Modüllere dön',
  'Get a list' => 'Göster',
  'Most Active Users Module Configuration' => '',
  'Save' => 'Kaydet',
  'The number of most active users that will be shown.' => '',
  'You may configure the number users to be shown.' => '',
);
