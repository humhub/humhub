<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Najbardziej</strong> aktywni ludzie',
  'Back to modules' => 'Powrót do modułów',
  'Get a list' => 'Pobierz listę',
  'Most Active Users Module Configuration' => 'Konfiguracja modułu Najbardziej Aktywnych Użytkowników',
  'Save' => 'Zapisz ',
  'The number of most active users that will be shown.' => 'Liczba najbardziej aktywnych użytkowników.',
  'You may configure the number users to be shown.' => 'Możesz ustawić liczbę użytkowników do wyświetlenia.',
);
