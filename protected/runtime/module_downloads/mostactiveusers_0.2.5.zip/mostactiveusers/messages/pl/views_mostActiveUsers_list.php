<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Najbardziej</strong> aktywni ludzie',
  'Comments created' => 'Utworzone komentarze',
  'Likes given' => 'Ilość polubień',
  'Posts created' => 'Wpisy utworzone',
);
