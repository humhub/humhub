<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Usuarios</strong> más activos',
  'Comments created' => 'Comentarios creados',
  'Likes given' => '"Me gusta" dados',
  'Posts created' => 'Entradas creadas',
);
