<?php
return array (
  '<strong>Most</strong> active people' => 'Die <strong>aktivsten</strong> Benutzer',
  'Comments created' => 'Erstellte Kommentare',
  'Likes given' => 'Gegebene Likes',
  'Posts created' => 'Erstellte Posts',
);
