<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Meest</strong> actieve personen',
  'Comments created' => 'Reacties aangemaakt',
  'Likes given' => 'Aantal "Vind ik leuk"',
  'Posts created' => 'Berichten aangemaakt',
);
