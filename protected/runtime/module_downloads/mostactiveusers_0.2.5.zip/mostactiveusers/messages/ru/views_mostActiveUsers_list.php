<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Самые</strong> активные пользователи',
  'Comments created' => 'Созданных комментариев',
  'Likes given' => 'Полученных лайков',
  'Posts created' => 'Созданных сообщений',
);
