<?php
return array (
  'Groups' => 'Grupy ',
  'Members' => 'Członkowie ',
  'Spaces' => 'Strefy ',
  'User Posts' => 'Posty użytkownika ',
);
