<?php
return array (
  'New message from {senderName}' => 'Nowa wiadomość od {senderName} ',
  'and {counter} other users' => 'i {counter} innych użytkowników ',
);
