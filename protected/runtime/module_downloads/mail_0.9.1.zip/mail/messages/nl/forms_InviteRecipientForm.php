<?php
return array (
  'Recipient' => 'Ontvanger',
  'You cannot send a email to yourself!' => 'Je kunt jezelf geen mail sturen!',
);
