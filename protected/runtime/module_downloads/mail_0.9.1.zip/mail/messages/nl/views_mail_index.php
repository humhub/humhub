<?php
return array (
  'Conversations' => 'Gesprekken',
  'New' => 'Nieuw',
  'New message' => 'Nieuw bericht',
  'There are no messages yet.' => 'Er zijn nog geen berichten.',
);
