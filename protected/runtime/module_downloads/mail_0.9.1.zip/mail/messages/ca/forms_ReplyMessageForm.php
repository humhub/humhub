<?php
return array (
  'Message' => 'Missatge',
);
