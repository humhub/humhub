<?php
return array (
  'Messages' => 'Missatges',
  'New message' => 'Nou missatge',
  'Show all messages' => 'Mostra tots els missatges',
);
