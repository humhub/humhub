<?php
return array (
  'Messages' => 'پیام‌ها',
);
