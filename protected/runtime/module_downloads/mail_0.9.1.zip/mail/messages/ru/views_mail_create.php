<?php
return array (
  'Add recipients' => 'Добавить получателей',
  'Close' => 'Закрыть',
  'New message' => 'Новое сообщение',
  'Send' => 'Отправить',
);
