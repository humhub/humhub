<?php
return array (
  'New message in discussion from %displayName%' => 'Новое сообщение в переписке от %displayName%',
);
