<?php
return array (
  'Message' => 'Besked',
  'Recipient' => 'Modtager',
  'Subject' => 'Emne',
  'You cannot send a email to yourself!' => 'Du kan ikke sende en mail til dig selv!',
);
