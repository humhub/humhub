<?php
return array (
  'You cannot send a email to yourself!' => 'Du kan ikke sende en besked til dig selv!',
);
