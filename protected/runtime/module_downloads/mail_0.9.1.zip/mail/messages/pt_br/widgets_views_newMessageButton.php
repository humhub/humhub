<?php
return array (
  'New message' => 'Nova mensagem',
  'Send message' => 'Enviar mensagem',
);
