<?php
return array (
  'Groups' => 'Grupos',
  'Members' => 'Usuários',
  'Spaces' => 'Espaços',
  'User Posts' => 'Posts do Usuário',
);
