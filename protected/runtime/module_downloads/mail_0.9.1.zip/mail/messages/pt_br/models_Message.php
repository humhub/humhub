<?php
return array (
  'New message from {senderName}' => 'Nova mensagem de {senderName}',
  'and {counter} other users' => 'e {counter} outros usuários',
);
