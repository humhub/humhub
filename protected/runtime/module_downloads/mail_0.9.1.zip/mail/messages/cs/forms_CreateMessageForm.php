<?php
return array (
  'Message' => 'Zpráva',
  'Recipient' => 'Příjemce',
  'Subject' => 'Předmět',
  'You cannot send a email to yourself!' => 'Nemůžete poslat zprávu sami sobě.',
);
