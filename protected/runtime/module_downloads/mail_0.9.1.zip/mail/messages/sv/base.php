<?php
return array (
  'Messages' => 'Meddelanden',
);
