<?php
return array (
  'New message in discussion from %displayName%' => 'Nouveau message dans la conversation de %displayName%',
);
