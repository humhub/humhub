<?php
return array (
  'Inbox' => 'البريد الوارد',
  'New' => 'جديد',
  'New message' => 'رسالة جديدة',
  'There are no messages yet.' => 'لا توجد رسائل',
);
