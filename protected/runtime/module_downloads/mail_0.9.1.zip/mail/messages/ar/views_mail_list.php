<?php
return array (
  'There are no messages yet.' => 'لا توجد رسائل',
);
