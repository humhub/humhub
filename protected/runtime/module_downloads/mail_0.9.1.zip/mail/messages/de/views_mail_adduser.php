<?php
return array (
  'Add more participants to your conversation...' => 'Füge der Konversation weitere Empfänger hinzu...',
  'Close' => 'Schließen',
  'Send' => 'Senden',
);
