<?php
return array (
  'Recipient' => 'Empfänger',
  'You cannot send a email to yourself!' => 'Du kannst dir selber keine Mail senden!',
);
