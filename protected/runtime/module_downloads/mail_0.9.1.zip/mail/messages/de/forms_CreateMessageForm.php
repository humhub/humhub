<?php
return array (
  'Message' => 'Nachricht',
  'Recipient' => 'Empfänger',
  'Subject' => 'Betreff',
  'You cannot send a email to yourself!' => 'Du kannst dir selber keine Mail senden!',
);
