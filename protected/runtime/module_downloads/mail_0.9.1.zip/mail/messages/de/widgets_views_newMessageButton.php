<?php
return array (
  'New message' => 'Neue Nachricht',
  'Send message' => 'Nachricht senden',
);
