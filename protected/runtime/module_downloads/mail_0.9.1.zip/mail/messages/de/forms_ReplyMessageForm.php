<?php
return array (
  'Message' => 'Nachricht',
);
