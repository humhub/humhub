<?php
return array (
  'Inbox' => '',
  'New' => '',
  'New message' => '',
  'There are no messages yet.' => '',
);
