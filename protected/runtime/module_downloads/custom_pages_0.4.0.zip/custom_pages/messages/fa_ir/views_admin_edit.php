<?php
return array (
  '<strong>Create</strong> page' => '<strong>ایجاد</strong> صفحه',
  '<strong>Edit</strong> page' => '<strong>ویرایش</strong> صفحه',
  'Content' => 'محتوا',
  'Default sort orders scheme: 100, 200, 300, ...' => 'طرح پیش‌فرض برای ترتیب‌های مرتب‌سازی: ۱۰۰، ۲۰۰، ۳۰۰، . . . ',
  'Delete' => 'حذف',
  'Page title' => 'عنوان صفحه',
  'Save' => 'ذخیره',
  'Sort Order' => 'ترتیب مرتب‌سازی',
  'URL' => 'آدرس',
);
