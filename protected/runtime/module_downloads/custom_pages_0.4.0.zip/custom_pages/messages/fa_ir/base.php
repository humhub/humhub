<?php
return array (
  'Create new Page' => 'ایجاد یک صفحه‌ی جدید',
  'Custom Pages' => 'صفحه‌های سفارشی‌شده',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'پیوند',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'راهبری',
  'No custom pages created yet!' => 'هنوز هیج صفحه‌ی سفارشی‌شده‌ای ایجاد نشده‌است!',
  'Sort Order' => 'ترتیب مرتب‌سازی',
  'Title' => 'عنوان',
  'Top Navigation' => 'منوی بالا',
  'Type' => 'تایپ',
  'User Account Menu (Settings)' => 'منوی حساب کاربری (تنظیمات)',
  'Without adding to navigation (Direct link)' => '',
);
