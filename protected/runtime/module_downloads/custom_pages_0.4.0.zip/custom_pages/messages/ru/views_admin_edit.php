<?php
return array (
  '<strong>Create</strong> page' => '<strong>Создать</strong> страницу',
  '<strong>Edit</strong> page' => '<strong>Редактировать</strong> страницу',
  'Content' => 'Содержание',
  'Default sort orders scheme: 100, 200, 300, ...' => 'По умолчанию схема сортировки заказов: 100, 200, 300, ...',
  'Delete' => 'Удалить',
  'Page title' => 'Заголовок страницы',
  'Save' => 'Сохранить',
  'Sort Order' => 'Порядок сортировки',
  'URL' => 'Ссылка',
);
