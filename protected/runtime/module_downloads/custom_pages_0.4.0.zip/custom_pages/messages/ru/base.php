<?php
return array (
  'Create new Page' => 'Создать новую страницу',
  'Custom Pages' => 'Персональные страницы',
  'HTML' => 'HTML',
  'IFrame' => 'Фрейм',
  'Link' => 'Ссылка',
  'MarkDown' => 'Форматирование',
  'Navigation' => 'Навигация',
  'No custom pages created yet!' => 'Персональные страницы пока не созданы!',
  'Sort Order' => 'Порядок сортировки',
  'Title' => 'Название',
  'Top Navigation' => 'Лучшие',
  'Type' => 'Тип',
  'User Account Menu (Settings)' => 'Аккаунт пользователя (настройки)',
  'Without adding to navigation (Direct link)' => 'Без добавления в навигацию (Прямая ссылка)',
);
