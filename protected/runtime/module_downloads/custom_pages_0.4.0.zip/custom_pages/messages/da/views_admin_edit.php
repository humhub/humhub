<?php
return array (
  '<strong>Create</strong> page' => '<strong>Opret</strong> side',
  '<strong>Edit</strong> page' => '<strong>Rediger</strong> side',
  'Content' => 'Indhold',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Standard sorteringsrækkefølge: 100, 200, 300, ...',
  'Delete' => 'Slet',
  'Page title' => 'Side titel',
  'Save' => 'Gem',
  'Sort Order' => 'Sorteringsrækkefølge',
  'URL' => 'URL',
);
