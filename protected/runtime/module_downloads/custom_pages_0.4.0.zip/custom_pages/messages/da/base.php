<?php
return array (
  'Create new Page' => 'Opret ny Side',
  'Custom Pages' => 'Tilpassede Sider',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Navigation',
  'No custom pages created yet!' => 'Ingen tilpassede sider er oprettet endnu!',
  'Sort Order' => 'Sorteringsrækkefølge',
  'Title' => 'Titel',
  'Top Navigation' => 'Top Navigation',
  'Type' => 'Type',
  'User Account Menu (Settings)' => 'Bruger Profil menu (Indstillinger)',
  'Without adding to navigation (Direct link)' => 'Uden at tilføje til navigation (Direkte link)',
);
