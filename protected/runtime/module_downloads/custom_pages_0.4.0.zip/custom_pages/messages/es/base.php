<?php
return array (
  'Create new Page' => 'Crear nueva página',
  'Custom Pages' => 'Páginas personalizadas',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Navegación',
  'No custom pages created yet!' => '¡No se han creado páginas personalizadas todavía!',
  'Sort Order' => 'Orden de clasificación',
  'Title' => 'Título',
  'Top Navigation' => 'Navegación superior',
  'Type' => 'Tipo',
  'User Account Menu (Settings)' => 'Menú de cuenta de usuario (ajustes)',
  'Without adding to navigation (Direct link)' => '',
);
