<?php
return array (
  'Create new Page' => 'Créer une nouvelle page',
  'Custom Pages' => 'Pages personnalisées',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Lien',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Menu de navigation',
  'No custom pages created yet!' => 'Aucune page personnalisée n\'a été créée !',
  'Sort Order' => 'Ordre de tri',
  'Title' => 'Titre',
  'Top Navigation' => 'Menu de navigation',
  'Type' => 'Type',
  'User Account Menu (Settings)' => 'Menu du compte utilisateur (paramètres)',
  'Without adding to navigation (Direct link)' => 'Sans l\'ajouter au menu de navigation (lien direct)',
);
