<?php
return array (
  'Create new Page' => 'Crea una nova pàgina',
  'Custom Pages' => 'Pàgines personalitzades',
  'HTML' => 'HTML',
  'IFrame' => 'Iframe',
  'Link' => 'Enllaç',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Navegació',
  'No custom pages created yet!' => 'Encara no has creat cap pàgina personalitzada!',
  'Sort Order' => 'Ordre de classificació',
  'Title' => 'Títol',
  'Top Navigation' => 'Barra de navegació',
  'Type' => 'Tipus',
  'User Account Menu (Settings)' => 'Menu del compte d\'usuari (Configuració)',
  'Without adding to navigation (Direct link)' => '',
);
