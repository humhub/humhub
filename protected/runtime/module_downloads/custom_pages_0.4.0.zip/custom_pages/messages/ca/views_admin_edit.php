<?php
return array (
  '<strong>Create</strong> page' => '<strong>Crea</strong> una pàgina',
  '<strong>Edit</strong> page' => '<strong>Edita</strong> la pàgina',
  'Content' => 'Contingut',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Ordre per defecte: 100, 200, 300, ...',
  'Delete' => 'Suprimeix',
  'Page title' => 'Títol de la pàgina',
  'Save' => 'Desa',
  'Sort Order' => 'Ordre',
  'URL' => 'URL',
);
