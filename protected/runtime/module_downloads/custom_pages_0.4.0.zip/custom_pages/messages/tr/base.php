<?php
return array (
  'Create new Page' => 'Yeni Sayfa Oluştur',
  'Custom Pages' => 'Özel Sayfalar',
  'HTML' => 'Html',
  'IFrame' => 'İframe',
  'Link' => 'Bağlantı',
  'MarkDown' => '',
  'Navigation' => 'Navigasyon',
  'No custom pages created yet!' => 'Özel sayfalar henüz oluşturulmadı!',
  'Sort Order' => 'Sıralama',
  'Title' => 'Başlık',
  'Top Navigation' => 'En Navigasyon',
  'Type' => 'Tip',
  'User Account Menu (Settings)' => 'Kullanıcı Hesap Menüsü (Ayarlar)',
  'Without adding to navigation (Direct link)' => '',
);
