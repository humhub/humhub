<?php
return array (
  '<strong>Create</strong> page' => '<strong>Sayfa</strong> oluştur',
  '<strong>Edit</strong> page' => '<strong>Sayfa</strong> düzenle',
  'Content' => 'İçerik',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Varsayılan sıralama düzeni: 100, 200, 300, ...',
  'Delete' => 'Sil',
  'Page title' => 'Sayfa Başlık',
  'Save' => 'Kaydet',
  'Sort Order' => 'Sıralama Düzeni',
  'URL' => 'Url',
);
