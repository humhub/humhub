<?php
return array (
  '<strong>Create</strong> page' => '<strong>Seite</strong> erstellen',
  '<strong>Edit</strong> page' => '<strong>Seite</strong> bearbeiten',
  'Content' => 'Inhalt',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Standard-Sortierschema: 100, 200, 300, ...',
  'Delete' => 'Löschen',
  'Page title' => 'Seitentitel',
  'Save' => 'Speichern',
  'Sort Order' => 'Sortierung',
  'URL' => 'URL',
);
