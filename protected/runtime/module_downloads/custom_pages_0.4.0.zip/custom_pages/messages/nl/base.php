<?php
return array (
  'Create new Page' => 'Nieuwe pagina',
  'Custom Pages' => 'Aangepaste pagina\'s',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'Markdown',
  'Navigation' => 'Navigatie',
  'No custom pages created yet!' => 'Geen aangepaste pagina\'s tot nu toe!',
  'Sort Order' => 'Sorteervolgorde',
  'Title' => 'Titel',
  'Top Navigation' => 'Hoofd navigatie',
  'Type' => 'Type',
  'User Account Menu (Settings)' => 'Gebruikers account menu (Opties) ',
  'Without adding to navigation (Direct link)' => '',
);
