<?php
return array (
  'Create new Page' => 'Crea nuova pagina',
  'Custom Pages' => 'Pagine personalizzate',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Menu',
  'No custom pages created yet!' => 'Nessun pagina ancora creata!',
  'Sort Order' => 'Ordinamento',
  'Title' => 'Titolo',
  'Top Navigation' => 'Top Menu',
  'Type' => 'Tipo',
  'User Account Menu (Settings)' => 'Menu impostazione per utenti',
  'Without adding to navigation (Direct link)' => '',
);
