<?php
return array (
  'Create new Page' => 'Criar nova página',
  'Custom Pages' => 'Personalizar Páginas',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Link',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Navegação',
  'No custom pages created yet!' => 'Não há páginas personalizadas criadas ainda!',
  'Sort Order' => 'Ordem de Classificação',
  'Title' => 'Título',
  'Top Navigation' => 'Menu Superior',
  'Type' => 'Tipo',
  'User Account Menu (Settings)' => 'Menu da Conta de Usuário (Configurações)',
  'Without adding to navigation (Direct link)' => '',
);
