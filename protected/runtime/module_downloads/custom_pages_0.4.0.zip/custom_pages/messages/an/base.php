<?php
return array (
  'Create new Page' => '',
  'Custom Pages' => '',
  'HTML' => '',
  'IFrame' => '',
  'Link' => '',
  'MarkDown' => '',
  'Navigation' => '',
  'No custom pages created yet!' => '',
  'Sort Order' => '',
  'Title' => 'Titulek',
  'Top Navigation' => '',
  'Type' => '',
  'User Account Menu (Settings)' => '',
  'Without adding to navigation (Direct link)' => '',
);
