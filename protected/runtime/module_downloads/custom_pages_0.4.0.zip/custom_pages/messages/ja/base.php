<?php
return array (
  'Create new Page' => '新しいページを作成します',
  'Custom Pages' => 'カスタム ページ',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'リンク',
  'MarkDown' => 'Markdown',
  'Navigation' => 'ナビゲーション',
  'No custom pages created yet!' => 'カスタム ページがありません!',
  'Sort Order' => '並べ替え順序',
  'Title' => 'タイトル',
  'Top Navigation' => 'トップ ナビゲーション',
  'Type' => 'タイプ',
  'User Account Menu (Settings)' => 'ユーザー アカウント メニュー (設定)',
  'Without adding to navigation (Direct link)' => '(直接リンク) ナビゲーションに追加しません。',
);
