<?php
return array (
  '<strong>Create</strong> page' => '<strong>作成し</strong> ページ',
  '<strong>Edit</strong> page' => '<strong>編集</strong> ページ',
  'Content' => 'コンテンツ',
  'Default sort orders scheme: 100, 200, 300, ...' => '既定の並べ替えの注文方式: 100 200 300...',
  'Delete' => '削除',
  'Page title' => 'ページのタイトル',
  'Save' => '保存',
  'Sort Order' => '並べ替え順序',
  'URL' => 'URL',
);
