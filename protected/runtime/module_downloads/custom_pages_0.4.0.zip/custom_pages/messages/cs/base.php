<?php
return array (
  'Create new Page' => 'Vytvořit novou stránku',
  'Custom Pages' => 'Vlastní stránky',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Odkaz',
  'MarkDown' => 'MarkDown',
  'Navigation' => 'Navigace',
  'No custom pages created yet!' => 'Zatím nebyla vytvořena žádná vlastní stránka.',
  'Sort Order' => 'Řazení',
  'Title' => 'Nadpis',
  'Top Navigation' => 'Hlavní navigace',
  'Type' => 'Typ',
  'User Account Menu (Settings)' => 'Uživatelské menu (nastavení)',
  'Without adding to navigation (Direct link)' => 'Nepřidávat do navigace (přímý odkaz)',
);
