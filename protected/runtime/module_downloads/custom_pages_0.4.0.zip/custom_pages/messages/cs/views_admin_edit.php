<?php
return array (
  '<strong>Create</strong> page' => '<strong>Vytvořit</strong> stránku',
  '<strong>Edit</strong> page' => '<strong>Změnit</strong> stránku',
  'Content' => 'Obsah',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Výchozí schéma řazení: 100, 200, 300...',
  'Delete' => 'Smazat',
  'Page title' => 'Titulek stránky',
  'Save' => 'Uložit',
  'Sort Order' => 'Řazení',
  'URL' => 'Adresa odkazu',
);
