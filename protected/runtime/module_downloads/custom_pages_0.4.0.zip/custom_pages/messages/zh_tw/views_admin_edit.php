<?php
return array (
  '<strong>Create</strong> page' => '',
  '<strong>Edit</strong> page' => '',
  'Content' => '',
  'Default sort orders scheme: 100, 200, 300, ...' => '',
  'Delete' => '',
  'Page title' => '',
  'Save' => '儲存',
  'Sort Order' => '',
  'URL' => '',
);
