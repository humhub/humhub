<?php
return array (
  '<strong>Create</strong> page' => '<strong>Sukurti</strong> puslapį',
  '<strong>Edit</strong> page' => '<strong>Redaguoti</strong> puslapį',
  'Content' => 'Turinys',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Numatytoji rūšiavimo tvarkos schema: 100, 200, 300, ...',
  'Delete' => 'Ištrinti',
  'Page title' => 'Puslapio pavadinimas',
  'Save' => 'Išsaugoti',
  'Sort Order' => 'Rūšiavimo tvarka',
  'URL' => 'URL',
);
