<?php
return array (
  'Create new Page' => 'Sukurti naują puslapį',
  'Custom Pages' => 'Įprasti puslapiai',
  'HTML' => 'HTML',
  'IFrame' => '',
  'Link' => 'Nuoroda',
  'MarkDown' => '',
  'Navigation' => 'Navigacija',
  'No custom pages created yet!' => 'Įprasti puslapiai kol kas nesukurti!',
  'Sort Order' => 'Rūšiavimo tvarka',
  'Title' => 'Pavadinimas',
  'Top Navigation' => 'Top navigacija',
  'Type' => 'Tipas',
  'User Account Menu (Settings)' => 'Vartotojo paskyros meniu (nustatymai)',
  'Without adding to navigation (Direct link)' => '',
);
