<?php
return array (
  '<strong>Create</strong> page' => '<strong>Utwórz</strong> stronę',
  '<strong>Edit</strong> page' => '<strong>Edytuj</strong> stronę',
  'Content' => 'Zawartość',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Domyślna kolejność sortowania: 100, 200, 300, ...',
  'Delete' => 'Usuń',
  'Page title' => 'Tytuł strony',
  'Save' => 'Zapisz ',
  'Sort Order' => 'Sortuj',
  'URL' => 'URL',
);
