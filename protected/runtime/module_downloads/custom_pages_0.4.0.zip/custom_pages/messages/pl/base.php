<?php
return array (
  'Create new Page' => 'Dodaj stronę',
  'Custom Pages' => 'Własne strony',
  'HTML' => 'HTML',
  'IFrame' => 'IFrame',
  'Link' => 'Odnośnik',
  'MarkDown' => 'Znaczniki MarkDown',
  'Navigation' => 'Nawigacja',
  'No custom pages created yet!' => 'Nie stworzono jeszcze własnych stron!',
  'Sort Order' => 'Sortuj',
  'Title' => 'Tytuł',
  'Top Navigation' => 'Górna nawigacja',
  'Type' => 'Rodzaj',
  'User Account Menu (Settings)' => 'Konto użytkownika (Ustawienia)',
  'Without adding to navigation (Direct link)' => 'Bez dodawania do nawigacji (odnośnik bezpośredni)',
);
