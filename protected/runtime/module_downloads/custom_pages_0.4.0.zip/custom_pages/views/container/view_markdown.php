<div class="panel panel-default">
    <div class="panel-body">
        <?php echo humhub\widgets\MarkdownView::widget(['markdown' => $md]); ?>
    </div>
</div>
