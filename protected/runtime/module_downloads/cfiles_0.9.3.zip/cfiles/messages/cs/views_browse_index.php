<?php
return array (
  'Could not save file %title%. ' => 'Nebylo možné uložit soubor %title%.',
);
