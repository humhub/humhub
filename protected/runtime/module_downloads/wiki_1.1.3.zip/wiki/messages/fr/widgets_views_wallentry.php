<?php
return array (
  'Open wiki page...' => 'Ouvir une page wiki...',
);
