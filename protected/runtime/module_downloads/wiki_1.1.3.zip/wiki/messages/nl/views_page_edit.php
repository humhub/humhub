<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Maak</strong> nieuwe pagina',
  '<strong>Edit</strong> page' => '<strong>Bewerk</strong> pagina',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Voer een paginanaam of URL in',
  'New page title' => 'Nieuwe paginatitel',
  'Page content' => 'Pagina inhoud',
  'Save' => 'Bewaar',
);
