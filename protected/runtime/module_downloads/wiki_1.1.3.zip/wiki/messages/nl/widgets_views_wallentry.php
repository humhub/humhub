<?php
return array (
  'Open wiki page...' => 'Open wiki pagina...',
);
