<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Utwórz</strong> nową stronę',
  '<strong>Edit</strong> page' => '<strong>Edytuj</strong> stronę',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Wprowadź tytuł wiki lub jej url (np. http://przykład.pl)',
  'New page title' => 'Nowy tytuł strony',
  'Page content' => 'Zawartość strony',
  'Save' => 'Zapisz ',
);
