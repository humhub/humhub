<?php
return array (
  'Wiki page' => 'Wiki side',
);
