<?php
return array (
  'Wiki page' => 'Wiki stránka',
);
