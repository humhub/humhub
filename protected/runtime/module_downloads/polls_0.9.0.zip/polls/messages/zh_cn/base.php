<?php
return array (
  'Polls' => '投票',
);
