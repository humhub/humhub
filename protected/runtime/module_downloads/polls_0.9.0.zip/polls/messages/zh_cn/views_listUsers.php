<?php
return array (
  'User who vote this' => '用户投票',
);
