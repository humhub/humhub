<?php
return array (
  'Polls' => 'Sondages',
);
