<?php
return array (
  'Ask' => 'Спросить',
);
