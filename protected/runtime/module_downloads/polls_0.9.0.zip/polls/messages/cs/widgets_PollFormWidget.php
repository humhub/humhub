<?php
return array (
  'Ask' => 'Položit otázku',
);
