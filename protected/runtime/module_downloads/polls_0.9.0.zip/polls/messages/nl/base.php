<?php
return array (
  'Polls' => 'Polls',
);
