<?php
return array (
  'Polls' => 'Afstemninger',
);
