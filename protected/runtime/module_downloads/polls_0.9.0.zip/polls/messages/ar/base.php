<?php
return array (
  'Polls' => '',
);
