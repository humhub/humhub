<?php
return array (
  '{userName} created a new {question}.' => '{userName} creó una nueva {question}.',
);
