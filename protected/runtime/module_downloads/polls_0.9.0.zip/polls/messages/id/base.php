<?php
return array (
  'Polls' => 'Pemungutan Suara',
);
