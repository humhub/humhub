<?php
return array (
  'Anonymous' => 'Anonimowo',
  'Closed' => 'Zamknięte',
  'Reset my vote' => 'Resetuj mój głos',
  'Vote' => 'Głos',
  'and {count} more vote for this.' => 'i {count} więcej głosów.',
  'votes' => 'głosy ',
);
