<?php
return array (
  'Add answer...' => 'Dodaj odpowiedź...',
  'Allow multiple answers per user?' => 'Zezwól na wielokrotne odpowiedzi na użytkownika? ',
  'Anonymous Votes?' => 'Głosy anonimowe?',
  'Ask something...' => 'Zapytaj o coś...',
  'Display answers in random order?' => 'Wyświetlaj odpowiedzi w losowej kolejności?',
  'Edit answer (empty answers will be removed)...' => 'Edytuj odpowiedź (puste odpowiedzi zostaną usunięte)...',
  'Edit your poll question...' => 'Edytuj pytanie głosowania...',
);
