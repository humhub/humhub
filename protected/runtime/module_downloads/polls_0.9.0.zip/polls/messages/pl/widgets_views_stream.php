<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Nie ma jeszcze sondy!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Nie ma jeszcze sondy!</b><br>Bądź pierwszy i utwórz jedną...',
  'Asked by me' => 'Moje zapytanie',
  'No answered yet' => 'Jeszcze nie odpowiedziano',
  'Only private polls' => 'Tylko prywatne głosowania',
  'Only public polls' => 'Tylko publiczne głosowania',
);
