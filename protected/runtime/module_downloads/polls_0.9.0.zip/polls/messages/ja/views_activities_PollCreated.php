<?php
return array (
  '{userName} created a new {question}.' => '{userName}さんは、新しいアンケート「{question}」を作成しました。',
);
