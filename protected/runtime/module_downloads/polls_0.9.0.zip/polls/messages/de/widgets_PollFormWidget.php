<?php
return array (
  'Ask' => 'Frage stellen',
);
