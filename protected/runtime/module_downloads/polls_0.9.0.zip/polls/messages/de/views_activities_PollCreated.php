<?php
return array (
  '{userName} created a new {question}.' => ' {userName} hat die Umfrage »{question}« erstellt.',
);
