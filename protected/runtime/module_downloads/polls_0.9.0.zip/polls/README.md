## Description

Simple polling system for spaces.

__Module website:__ <https://github.com/humhub/humhub-modules-polls>  
__Author:__ luke, andystrobel  
__Author website:__ [humhub.org](http://humhub.org)

## Changelog
v 0.8.0:
    - Anonymous Poll
    - Close Poll
    - Edit Poll
    - Random Poll answers
<https://github.com/humhub/humhub-modules-polls/commits/master>

## Bugtracker

<https://github.com/humhub/humhub-modules-polls/issues>