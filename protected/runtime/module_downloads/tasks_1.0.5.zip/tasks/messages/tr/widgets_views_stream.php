<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  'Back to stream' => '@@Akışlara geri dön@@',
  'No tasks found which matches your current filter(s)!' => '@@Filtrenize uygun görev bulunamadı!@@',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Henüz görev yok!</b><br>İlk görevi oluşturun...',
  'Assigned to me' => 'Bana atanan',
  'Created by me' => 'Açtıklarım',
  'Creation time' => 'Oluşturma süresi',
  'Filter' => 'Filtre',
  'Last update' => 'Son güncelleme',
  'Nobody assigned' => 'Hiç kimseye atanan',
  'Sorting' => 'Sıralama',
  'State is finished' => 'Durum sona erdi',
  'State is open' => 'Durum açık',
);
