<?php
return array (
  '{userName} finished task {task}.' => '{task} Görev sona erdi {userName} .',
);
