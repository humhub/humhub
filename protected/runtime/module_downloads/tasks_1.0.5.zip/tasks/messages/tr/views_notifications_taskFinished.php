<?php
return array (
  '{userName} finished task {task}.' => '{userName} görev sona erdi {task}.',
);
