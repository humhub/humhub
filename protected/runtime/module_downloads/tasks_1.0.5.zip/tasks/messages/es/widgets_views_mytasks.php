<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Mis</strong> tareas',
  'From space: ' => 'Del espacio:',
);
