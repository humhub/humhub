<?php
return array (
  'Create' => 'Crea',
);
