<?php
return array (
  '{userName} created a new task {task}.' => '{userName} sukūrė naują užduotį {task}.',
);
