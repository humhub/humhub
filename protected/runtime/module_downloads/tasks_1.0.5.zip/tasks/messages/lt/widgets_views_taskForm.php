<?php
return array (
  'Assign users to this task' => 'Priskirkite vartotojus šiai užduočiai',
  'Deadline for this task?' => 'Šios užduoties atlikimo terminas?',
  'Preassign user(s) for this task.' => 'Iš naujo priskirkite vartotoją (-us) šiai užduočiai.',
  'What to do?' => 'Ką daryti?',
);
