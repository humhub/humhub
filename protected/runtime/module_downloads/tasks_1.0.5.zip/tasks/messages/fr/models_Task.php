<?php
return array (
  'Task' => 'Tâche',
);
