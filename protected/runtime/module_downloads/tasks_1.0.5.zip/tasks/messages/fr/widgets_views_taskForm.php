<?php
return array (
  'Assign users to this task' => 'Assigner des utilisateurs à cette tâche',
  'Deadline for this task?' => '',
  'Preassign user(s) for this task.' => '',
  'What to do?' => 'Qu\'y a t-il à faire ?',
);
