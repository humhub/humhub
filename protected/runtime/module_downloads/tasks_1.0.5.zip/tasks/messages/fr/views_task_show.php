<?php
return array (
  '<strong>Confirm</strong> deleting' => '',
  'Add Task' => 'Ajouter une tâche',
  'Cancel' => 'Annuler',
  'Delete' => 'Effacer',
  'Do you really want to delete this task?' => 'Vouhaitez-vous vraiment supprimer cette tâche ?',
  'No open tasks...' => '',
  'completed tasks' => '',
);
