<?php
return array (
  'Task' => 'Задача',
);
