<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Мои</strong> задачи',
  'From space: ' => 'Из пространства:',
);
