<?php
return array (
  'Assign users to this task' => 'Связать пользователей с этой задачей',
  'Deadline for this task?' => 'Срок для решения этой задачи?',
  'Preassign user(s) for this task.' => 'Предварительный (е) пользователь (и) этой задачи.',
  'What to do?' => 'Что сделать?',
);
