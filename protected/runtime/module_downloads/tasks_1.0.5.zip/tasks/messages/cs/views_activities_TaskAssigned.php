<?php
return array (
  '{userName} assigned to task {task}.' => 'Uživateli {userName} byl přiřazen úkol {task}.',
);
