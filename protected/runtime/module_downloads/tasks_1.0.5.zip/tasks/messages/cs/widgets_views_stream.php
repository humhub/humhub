<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  'Back to stream' => '@@Zpět na příspěvky@@',
  'No tasks found which matches your current filter(s)!' => '@@Nebyl nalezen žádný úkol, který by odpovídal filtrům, které jste zvolil(a).@@',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Zatím zde nejsou žádné úkoly.</b><br> Vytvořte první...',
  'Assigned to me' => 'Přiřazených mně',
  'Created by me' => 'Vytvořil(a) jsem',
  'Creation time' => 'Vytvořeno',
  'Filter' => 'Filtr',
  'Last update' => 'Změněno',
  'Nobody assigned' => 'Nepřiřazen nikomu',
  'Sorting' => 'Řazení',
  'State is finished' => 'Dokončené',
  'State is open' => 'Otevřené',
);
