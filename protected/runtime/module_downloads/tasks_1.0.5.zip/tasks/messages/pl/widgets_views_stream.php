<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Nie ma jeszcze zadań!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Jeszcze nie ma żadnych zadań!</b><br>Bądź pierwszym który je utworzy...',
  'Assigned to me' => 'Przypisane do mnie',
  'Back to stream' => '@@Powrót do strumienia@@',
  'Created by me' => 'Utworzone przeze mnie ',
  'Creation time' => 'Czas utworzenia',
  'Filter' => 'Filtr',
  'Last update' => 'Ostatnia aktualizacja',
  'No tasks found which matches your current filter(s)!' => '@@Nie znaleziono zadań pasujących do obecnego filtru(-ów)!@@',
  'Nobody assigned' => 'Nikogo nie przypisano',
  'Sorting' => 'Sortowanie',
  'State is finished' => 'Stan zakończony',
  'State is open' => 'Stan otwarty ',
);
