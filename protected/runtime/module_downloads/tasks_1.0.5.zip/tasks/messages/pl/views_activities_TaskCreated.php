<?php
return array (
  '{userName} created task {task}.' => '{userName} utworzył zadanie {task}.',
);
