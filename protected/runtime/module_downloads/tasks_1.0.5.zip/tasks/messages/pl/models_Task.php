<?php
return array (
  'Task' => 'Zadanie',
);
