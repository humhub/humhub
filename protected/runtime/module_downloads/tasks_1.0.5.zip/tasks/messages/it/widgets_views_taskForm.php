<?php
return array (
  'Assign users to this task' => 'Assegna utenti a quest\'attività',
  'Deadline for this task?' => 'La scadenza per quest\'attività?',
  'Preassign user(s) for this task.' => 'Preassegna utenti a quest\'attività.',
  'What to do?' => 'Cosa c\'è da fare?',
);
