<?php
return array (
  '{userName} created a new task {task}.' => '{userName} ha creato la nuova attività {task}.',
);
