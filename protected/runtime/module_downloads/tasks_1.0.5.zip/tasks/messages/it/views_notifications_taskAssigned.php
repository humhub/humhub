<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} ti ha assegnato l\'attività {task}.',
);
