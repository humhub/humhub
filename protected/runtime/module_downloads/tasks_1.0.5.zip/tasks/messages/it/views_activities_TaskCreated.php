<?php
return array (
  '{userName} created task {task}.' => '{userName} ha creato l\'attività {task}.',
);
