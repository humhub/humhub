<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Conferma</strong> eliminazione',
  'Add Task' => 'Aggiungi attività',
  'Cancel' => 'Annulla',
  'Delete' => 'Elimina',
  'Do you really want to delete this task?' => 'Vuoi veramente eliminare quest\'attività?',
  'No open tasks...' => 'Nessun\'attività aperta...',
  'completed tasks' => 'Attività completate',
);
