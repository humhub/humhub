<?php
return array (
  'Could not access task!' => 'Non posso accedere all\'attività!',
);
