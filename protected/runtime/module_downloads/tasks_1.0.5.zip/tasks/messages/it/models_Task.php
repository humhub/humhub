<?php
return array (
  'Task' => 'Attività',
);
