<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Mine</strong> opgaver',
  'From space: ' => 'Fra side:',
);
