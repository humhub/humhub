<?php
return array (
  'Assign users to this task' => 'Tilføj brugere til denne opgave',
  'Deadline for this task?' => 'Deadline for denne opgave?',
  'Preassign user(s) for this task.' => 'Prætildel bruger(e) til denne opgave',
  'What to do?' => 'Hvad skal gøres?',
);
