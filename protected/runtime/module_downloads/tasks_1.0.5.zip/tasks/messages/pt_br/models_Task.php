<?php
return array (
  'Task' => 'Tarefa',
);
