<?php
return array (
  '{userName} finished task {task}.' => '{userName} finalizou a tarefa {task}.',
);
