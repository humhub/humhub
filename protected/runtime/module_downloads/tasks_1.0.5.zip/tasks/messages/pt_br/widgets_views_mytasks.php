<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Minhas</strong> tarefas',
  'From space: ' => 'Do espaço:',
);
