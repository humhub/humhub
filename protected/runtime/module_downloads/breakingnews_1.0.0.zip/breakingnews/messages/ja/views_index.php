<?php
return array (
  'Close' => '閉じる',
);
