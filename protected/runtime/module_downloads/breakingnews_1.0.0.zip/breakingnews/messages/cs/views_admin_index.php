<?php
return array (
  'Back to modules' => 'Zpět na přehled modulů',
  'Breaking News Configuration' => 'Nastavení modulu Horká novinka',
  'Note: You can use markdown syntax.' => 'Poznámka: můžete využít syntaxe markdown.',
  'Save' => 'Uložit',
);
