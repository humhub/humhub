<?php
return array (
  'Close' => 'Lukk',
);
