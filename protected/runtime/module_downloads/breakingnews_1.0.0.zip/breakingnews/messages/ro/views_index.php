<?php
return array (
  'Close' => 'Închide',
);
