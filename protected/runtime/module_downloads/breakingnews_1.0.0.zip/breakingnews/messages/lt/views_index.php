<?php
return array (
  'Close' => 'Uždaryti',
);
