<?php
return array (
  'Back to modules' => 'Retour aux modules',
  'Breaking News Configuration' => '',
  'Note: You can use markdown syntax.' => '',
  'Save' => 'Enregistrer',
);
