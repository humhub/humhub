<?php
return array (
  'Close' => 'Chiudi',
);
