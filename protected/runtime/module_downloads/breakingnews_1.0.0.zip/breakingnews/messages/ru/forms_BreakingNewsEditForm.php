<?php
return array (
  'Active' => 'Активно',
  'Mark as unseen for all users' => 'Пометить как "Непросмотренное" для всех пользователей',
  'Message' => 'Сообщение',
  'Title' => 'Заголовок',
);
