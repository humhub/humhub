<?php
return array (
  'Back to modules' => '',
  'Breaking News Configuration' => '',
  'Note: You can use markdown syntax.' => '',
  'Save' => '',
);
