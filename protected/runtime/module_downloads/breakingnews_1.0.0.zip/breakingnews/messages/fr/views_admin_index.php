<?php
return array (
  'Back to modules' => 'Retour aux modules',
  'Breaking News Configuration' => 'Configuration de Breaking News',
  'Note: You can use markdown syntax.' => 'Note : vous pouvez utiliser la syntaxe Markdown',
  'Save' => 'Enregistrer',
);
