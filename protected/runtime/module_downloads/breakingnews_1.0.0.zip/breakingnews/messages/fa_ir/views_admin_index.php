<?php
return array (
  'Back to modules' => 'بازگشت به ماژول‌ها',
  'Breaking News Configuration' => 'تنظیمات اخبار لحظه‌ای',
  'Note: You can use markdown syntax.' => 'توجه: می‌توانید از قواعد نحوی مد‌ل‌های نشانه‌گذاری استفاده کنید.',
  'Save' => 'ذخیره',
);
