<?php
return array (
  'Close' => 'Cerrar',
);
