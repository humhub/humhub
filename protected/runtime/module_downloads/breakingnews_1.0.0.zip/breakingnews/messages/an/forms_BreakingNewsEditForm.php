<?php
return array (
  'Active' => 'Aktivovat',
  'Mark as unseen for all users' => 'Označit jako nepřečtené pro všechny uživatele',
  'Message' => 'Zpráva',
  'Title' => 'Titulek',
);
