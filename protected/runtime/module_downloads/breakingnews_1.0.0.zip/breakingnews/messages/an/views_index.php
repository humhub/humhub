<?php
return array (
  'Close' => 'Zavřít',
);
