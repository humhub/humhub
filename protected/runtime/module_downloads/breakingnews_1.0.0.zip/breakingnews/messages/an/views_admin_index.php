<?php
return array (
  'Back to modules' => 'Zpět k modulům',
  'Breaking News Configuration' => '',
  'Note: You can use markdown syntax.' => '',
  'Save' => 'Uložit',
);
