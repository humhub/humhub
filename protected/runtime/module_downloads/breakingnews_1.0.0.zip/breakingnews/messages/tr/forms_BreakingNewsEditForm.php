<?php
return array (
  'Active' => 'Aktif',
  'Mark as unseen for all users' => 'Tüm kullanıcılar için işaretle olarak görünmeyen',
  'Message' => 'Mesaj',
  'Title' => 'Başlık',
);
