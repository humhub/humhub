<?php
return array (
  'Close' => 'İptal',
);
