<?php
return array (
  'Active' => 'Actiu',
  'Mark as unseen for all users' => 'Marca com a no llegit per a tots els membres',
  'Message' => 'Missatge',
  'Title' => 'Títol',
);
