<?php
return array (
  'Active' => 'Ativo',
  'Mark as unseen for all users' => 'Marcar como invisível para todos usuários',
  'Message' => 'Mensagem',
  'Title' => 'Título',
);
